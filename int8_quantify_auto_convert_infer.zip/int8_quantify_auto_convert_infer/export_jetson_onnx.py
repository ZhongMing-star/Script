from ultralytics import YOLO
import onnx
import onnx.helper as helper
from onnxsim import simplify
import os
import argparse


"""
python export_jetson_onnx.py --model_file /data0/backup/all_users/chentuo/ultralytics-main/runs/train_yw/yw_1280_seg_35/weights/best.pt --width 1280 --height 736
"""
def export_onnx(mode_file, width, height):
    pt_model = YOLO(mode_file)
    convert_success_path = pt_model.export(format="onnx", batch=1, imgsz=(height, width), opset=12)
    print(convert_success_path)
    return convert_success_path

def v8trans_v8onnxsim(onnx_file):
    prefix, suffix = os.path.splitext(onnx_file)
    dst_name = prefix + "-transd-trends-sim" + suffix

    onnx_model = onnx.load(onnx_file)
    node = onnx_model.graph.node[-1]

    old_output = node.output[0]
    node.output[0] = "pre_transpose"

    for specout in onnx_model.graph.output:
        if specout.name == old_output:
            shape0 = specout.type.tensor_type.shape.dim[0]
            shape1 = specout.type.tensor_type.shape.dim[1]
            shape2 = specout.type.tensor_type.shape.dim[2]
            new_out = helper.make_tensor_value_info(
                specout.name,
                specout.type.tensor_type.elem_type,
                [0, 0, 0]
            )
            new_out.type.tensor_type.shape.dim[0].CopyFrom(shape0)
            new_out.type.tensor_type.shape.dim[2].CopyFrom(shape1)
            new_out.type.tensor_type.shape.dim[1].CopyFrom(shape2)
            specout.CopyFrom(new_out)

    onnx_model.graph.node.append(
        helper.make_node("Transpose", ["pre_transpose"], [old_output], perm=[0, 2, 1])
    )
    model_simp, check = simplify(onnx_model)
    assert check, "Simplified ONNX model could not be Validated"
    print(f"YOLOv8 transd-trends-sim ONNX Model save to {dst_name}")
    onnx.save(onnx_model, dst_name)
    os.remove(onnx_file)  # 删除中间onnx文件
    return dst_name

def parse_args():
    parser = argparse.ArgumentParser(description='YOLOv8 ONNX Conversion and Simplification')
    parser.add_argument('--model_file', type=str, help='Path to the YOLOv8 .pt file, pt name eg:yolov8n_person_car_boat.pt')
    parser.add_argument('--width', type=int, default=1280, help='width of model input')
    parser.add_argument('--height', type=int, default=1280 , help='height of model input')
    return parser.parse_args()

def main():
    args = parse_args()
    model_file = args.model_file
    model_input_width = args.width
    model_input_height = args.height
    onnx_mode_path = export_onnx(model_file, model_input_width, model_input_height)
    v8trans_v8onnxsim(onnx_mode_path)

if __name__ == '__main__':
    main()