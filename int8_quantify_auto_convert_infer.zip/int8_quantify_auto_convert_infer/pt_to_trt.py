from __future__ import print_function
import argparse
import traceback
import tensorrt as trt
import time
import glob
import os
from calibrator import DataLoader
from onnx_to_trt import build_engine_from_onnx
from export_jetson_onnx import export_onnx, v8trans_v8onnxsim

"""
rm /data0/backup/all_users/chentuo/ultralytics-main/runs/train_hebing/train_hebing_4/weights/yolov8s_hebing_int8.cache
CUDA_VISIBLE_DEVICES=2 python pt_to_trt.py   --model /data0/backup/all_users/chentuo/ultralytics-main/runs/train_hebing/train_hebing_4/weights/yolov8s_hebing.pt \
                            --calib_img_dir /data0/backup/all_users/chentuo/A_PTQ/hebing_test/images \
                            --calib_cache /data0/backup/all_users/chentuo/ultralytics-main/runs/train_hebing/train_hebing_4/weights/yolov8s_hebing_int8.cache \
                            --dtype int8 \
                            --width 1280 \
                            --height 1280 \
                            --batch_size 8 
"""
def parse_args():
    parser = argparse.ArgumentParser(description='YOLOv8 ONNX Conversion and Simplification')
    # 添加引擎输出路径参数
    parser.add_argument('--engine_path', type=str, required=True, help='Path to save the generated TensorRT engine')
    parser.add_argument('--model_file', type=str, help='Path to the YOLOv8 .pt file, pt name eg:yolov8n_person_car_boat.pt')
    parser.add_argument('--width', type=int, default=1280, help='width of model input')
    parser.add_argument('--height', type=int, default=1280 , help='height of model input')


    parser.add_argument(
        '-v', '--verbose', action='store_true',
        help='enable verbose output (for debugging)')
    parser.add_argument(
        '-d', '--dtype', type=str, required=True,
        help='one type of int8, fp16, fp32')
    parser.add_argument('--dynamic-shape', action='store_true',
        help='Dynamic shape,  defer specifying some or all tensor dimensions until runtime')
    parser.add_argument(
        '--qat', action='store_true',
        help='whether the onnx model is qat; if it is, the int8 calibrator is not needed')
    
    # If enable int8(not post-QAT model), then set the following
    parser.add_argument('--batch_size', type=int,
                        default=32, help='batch size for training: default 64')
    parser.add_argument('--num_calib_batch', default=0, type=int,
                        help='Number of batches for calibration')
    parser.add_argument('--calib_img_dir', default='../coco/images/train2017', type=str,
                        help='Number of batches for calibration')
    parser.add_argument('--calib_cache', default='./trt/yolov5s_calibration.cache', type=str,
                        help='Path of calibration cache')
    parser.add_argument('--calib_method', default='minmax', type=str,
                        help='Calibration method')
    # 模型精度设置
    parser.add_argument('--fp32_layer_names', type=str, default='',
                        help='该层设为FP32精度')
    parser.add_argument('--fp16_layer_names', type=str, default='model.22 node_of_output0',
                        help='该层设为FP16精度, 默认为YOLOv8s的Detect层model.22和node_of_output0, YOLOv8s-p6的Detect层对应model.30')
    return parser.parse_args()


def main():
    args = parse_args()
    print(f'{os.path.basename(args.model_file)} 转换开始！')
    # 第一步：转onnx
    t1 = time.time()
    onnx_mode_path = export_onnx(args.model_file, args.width, args.height)
    onnx_new_path = v8trans_v8onnxsim(onnx_mode_path)
    print(f'转onnx完成！耗时{round(time.time() - t1, 2)}秒！')
    

    # 第二步：转trt
    print('开始进行转TRT！')
    t2 = time.time()
    # 设置0自动获取校准batch数
    if args.num_calib_batch == 0:      
        num_calib_batch = len(glob.glob(os.path.join(args.calib_img_dir, "*.jpg"))) // args.batch_size
    else:
        num_calib_batch = args.num_calib_batch

    if args.dtype == "int8" and not args.qat:
        calib_loader = DataLoader(args.batch_size,
                                  num_calib_batch, 
                                  args.calib_img_dir,
                                  args.width, 
                                  args.height)

        engine = build_engine_from_onnx(onnx_new_path, 
                                        args.dtype, 
                                        args.verbose,
                                        int8_calib=True, 
                                        calib_loader=calib_loader, 
                                        calib_cache=args.calib_cache,
                                        dynamic_shape=args.dynamic_shape,
                                        fp32_layer_names=args.fp32_layer_names,
                                        fp16_layer_names=args.fp16_layer_names)
    else:
        engine = build_engine_from_onnx(onnx_new_path,
                                        args.dtype, 
                                        args.verbose,
                                        dynamic_shape=args.dynamic_shape)

    if engine is None:
        raise SystemExit('ERROR: failed to build the TensorRT engine!')

    engine_path = onnx_new_path.replace('.onnx', '.engine')
    if args.dtype == "int8" and not args.qat:
        engine_path = onnx_new_path.replace('.onnx', '-int8.engine')

    # 删除原有engine_path生成逻辑，直接使用外部传入的路径
    engine_path = args.engine_path

    with open(engine_path, 'wb') as f:
        f.write(engine.serialize())
    print('Serialized the TensorRT engine to file: %s' % engine_path)
    print(f'转trt完成！耗时{round(time.time() - t2, 2)}秒！')
    print(f'{os.path.basename(args.model_file)} 转TRT完成！')


if __name__ == '__main__':
    main()