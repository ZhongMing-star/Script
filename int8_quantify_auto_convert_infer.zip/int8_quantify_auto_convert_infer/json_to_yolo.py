import argparse
import json
import os
import os.path as osp
import time
from PIL import Image
from tqdm import tqdm

class CustomToYoloConverter:
    def __init__(self, classes_file):
        # 加载类别文件并创建名称到ID的映射
        with open(classes_file, 'r', encoding='utf-8') as f:
            self.classes = f.read().splitlines()
        self.class_mapping = {name: idx for idx, name in enumerate(self.classes)}
        print(f"已加载类别: {len(self.classes)} 个类别")

    def convert_json_to_yolo(self, json_path, output_txt_path):
        # 读取JSON标注文件
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        image_width = data['imageWidth']
        image_height = data['imageHeight']

        # 写入YOLO格式TXT文件
        with open(output_txt_path, 'w', encoding='utf-8') as f:
            for shape in data['shapes']:
                label = shape['label']
                points = shape['points']

                # 获取类别ID
                if label not in self.class_mapping:
                    print(f"警告: 未知类别 '{label}'，已跳过")
                    continue
                class_id = self.class_mapping[label]

                # 计算归一化坐标（支持矩形的两种点格式）
                if len(points) == 4:  # 矩形四个顶点
                    x_min = min(p[0] for p in points)
                    y_min = min(p[1] for p in points)
                    x_max = max(p[0] for p in points)
                    y_max = max(p[1] for p in points)
                elif len(points) == 2:  # 对角点
                    x_min, y_min = points[0]
                    x_max, y_max = points[1]
                else:
                    print(f"警告: 不支持的形状点格式，已跳过")
                    continue

                # 归一化计算
                x_center = (x_min + x_max) / 2 / image_width
                y_center = (y_min + y_max) / 2 / image_height
                width = (x_max - x_min) / image_width
                height = (y_max - y_min) / image_height

                # 写入TXT（类别ID 中心x 中心y 宽 高）
                f.write(f"{class_id} {x_center} {y_center} {width} {height}\n")

    def batch_convert(self, src_dir, dst_dir):
        # 创建输出目录
        os.makedirs(dst_dir, exist_ok=True)

        # 遍历所有JSON文件
        json_files = [f for f in os.listdir(src_dir) if f.endswith('.json')]
        for json_file in tqdm(json_files, desc="转换进度", unit="文件"):
            src_path = osp.join(src_dir, json_file)
            txt_file = osp.splitext(json_file)[0] + '.txt'
            dst_path = osp.join(dst_dir, txt_file)
            self.convert_json_to_yolo(src_path, dst_path)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='自定义JSON转YOLO格式工具')
    parser.add_argument('--src_path', required=True, help='JSON标注文件目录')
    parser.add_argument('--dst_path', required=True, help='YOLO TXT输出目录')
    parser.add_argument('--classes', required=True, help='类别定义文件路径')
    args = parser.parse_args()

    print(f"开始转换: {args.src_path} -> {args.dst_path}")
    start_time = time.time()

    converter = CustomToYoloConverter(args.classes)
    converter.batch_convert(args.src_path, args.dst_path)

    end_time = time.time()
    print(f"转换完成！耗时: {end_time - start_time:.2f}秒")
    print(f"输出目录: {args.dst_path}")