import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

import torch
import torch.nn as nn
import numpy as np
import tensorrt as trt
from collections import OrderedDict, namedtuple
import json

import cv2
import time

# Binding 命名元组
Binding = namedtuple("Binding", ("name", "dtype", "shape", "data", "ptr"))

# TensorRT -> PyTorch dtype 映射
trt_to_torch_dtype_dict = {
    trt.DataType.BOOL: torch.bool,
    trt.DataType.INT8: torch.int8,
    trt.DataType.INT32: torch.int32,
    trt.DataType.HALF: torch.float16,
    trt.DataType.FLOAT: torch.float32,
}

# NumPy -> PyTorch dtype 映射
np_to_torch_dtype = {
    np.bool_: torch.bool,
    np.uint8: torch.uint8,
    np.int8: torch.int8,
    np.int16: torch.int16,
    np.int32: torch.int32,
    np.int64: torch.int64,
    np.float16: torch.float16,
    np.float32: torch.float32,
    np.float64: torch.float64
}


class UnifiedTRTModel(nn.Module):
    def __init__(
        self,
        weights="yolo11n.engine",
        device=torch.device("cuda:0"),
        fp16=False,
        input_names=['images'],
        output_names=None,
        fixed_output_shapes=None
    ):
        """
        统一的 TensorRT 模型封装器，支持 YOLO、xfeat 等多种模型。

        参数:
            weights (str): TensorRT engine 文件路径。
            device (torch.device): 推理设备，默认为 cuda:0。
            fp16 (bool): 是否启用半精度推理。
            input_names (list): 输入张量名称列表。
            output_names (list): 输出张量名称列表（可选，自动读取）。
            fixed_output_shapes (dict): 固定输出 shape，如 {'output': (1000, 2)}。
        """
        super().__init__()
        self.np_to_torch_dtype = np_to_torch_dtype
        self.trt_to_torch_dtype = trt_to_torch_dtype_dict
        self.input_names = input_names
        self.output_names = output_names
        self.fixed_output_shapes = fixed_output_shapes or {}
        self.fp16 = fp16
        self.device = device if device.type != "cpu" else torch.device("cpu")
        self.stream = torch.cuda.Stream(device=device) if torch.cuda.is_available() else None

        # 获取权重文件路径
        w = str(weights[0] if isinstance(weights, list) else weights)
        logger = trt.Logger(trt.Logger.INFO)
        trt.init_libnvinfer_plugins(logger, namespace='')
        
        print(f"Loading {w} for TensorRT inference...")
        with open(w, "rb") as f, trt.Runtime(logger) as runtime:
            try:
                meta_len = int.from_bytes(f.read(4), byteorder="little")
                metadata = json.loads(f.read(meta_len).decode("utf-8"))
            except UnicodeDecodeError:
                f.seek(0)
                metadata = None
            model = runtime.deserialize_cuda_engine(f.read())
        
        context = model.create_execution_context()
        is_trt10 = not hasattr(model, "num_bindings")
        
        # 自动获取输出名称 & 解析绑定信息（合并版本）
        bindings = OrderedDict()
        binding_addrs = OrderedDict()
        dynamic = False
        fp16 = False
        output_names = []

        for i in (range(model.num_io_tensors) if is_trt10 else range(model.num_bindings)):
            if is_trt10:
                name = model.get_tensor_name(i)
                dtype = trt.nptype(model.get_tensor_dtype(name))
                if model.get_tensor_mode(name) == trt.TensorIOMode.INPUT:
                    if -1 in tuple(context.get_tensor_shape(name)):
                        dynamic = True
                        context.set_input_shape(name, tuple(model.get_tensor_profile_shape(name, 0)[1]))
                        
                    if dtype == np.float16:
                        fp16 = True
                elif model.get_tensor_mode(name) == trt.TensorIOMode.OUTPUT:
                    output_names.append(name)
                shape = tuple(context.get_tensor_shape(name))
            else:
                name = model.get_binding_name(i)
                dtype = trt.nptype(model.get_binding_dtype(i))
                if model.binding_is_input(i):
                    if -1 in tuple(model.get_binding_shape(i)):
                        dynamic = True
                        context.set_binding_shape(i, tuple(model.get_profile_shape(0, i)[1]))
                    if dtype == np.float16:
                        fp16 = True
                elif model.get_tensor_mode(name) == trt.TensorIOMode.OUTPUT:
                    output_names.append(name)
                shape = tuple(context.get_binding_shape(i))

            # 注意：替换xfeat shape(0, 2)-->(1000, 2)
            if name in self.fixed_output_shapes:
                shape = self.fixed_output_shapes[name]

            # 创建 buffer 并记录地址
            im = torch.from_numpy(np.empty(shape, dtype=dtype)).to(self.device)
            bindings[name] = Binding(name, dtype, shape, im, int(im.data_ptr()))
            binding_addrs[name] = int(im.data_ptr())

        # 去重输出名称（防止重复）
        self.output_names = list(dict.fromkeys(output_names))

        # 注册变量
        self.model = model
        self.context = context
        self.bindings = bindings
        self.binding_addrs = binding_addrs
        self.dynamic = dynamic
        self.is_trt10 = is_trt10

    def forward(self, *inputs):
        """
        推理函数，支持多输入和手动设置输出 shape。

        参数:
            *inputs: 输入张量列表（顺序需与 input_names 一致）

        返回:
            tuple: 输出张量列表
        """
        
        assert len(inputs) == len(self.input_names), \
            f"Expected {len(self.input_names)} inputs but got {len(inputs)}"

        contiguous_inputs = [x.contiguous().to(self.device) for x in inputs]
        for i, input_name in enumerate(self.input_names):
            im = contiguous_inputs[i]
            if self.fp16 and im.dtype != torch.float16:
                im = im.half()
      
            if self.dynamic and im.shape != self.bindings[input_name].shape:
                if self.is_trt10:
                    self.context.set_input_shape(input_name, im.shape)
                    self.bindings[input_name] = self.bindings[input_name]._replace(shape=im.shape)
          
                    # 确保双输入尺寸对应后再修改输出尺寸
                    if i == len(self.input_names) - 1:
                        for name in self.output_names:
                            # 注意：替换xfeat shape(0, 2)-->(1000, 2)
                            if name in self.fixed_output_shapes:
                                shape = self.fixed_output_shapes[name]
                                self.bindings[name].data.resize_(shape)
                            else:
                                self.bindings[name].data.resize_(tuple(self.context.get_tensor_shape(name)))

                else:
                    idx = self.model.get_binding_index(input_name)
                    self.context.set_binding_shape(idx, im.shape)
                    self.bindings[input_name] = self.bindings[input_name]._replace(shape=im.shape)

                    # 确保双输入尺寸对应后再修改输出尺寸
                    if i == len(self.input_names) - 1:
                        for name in self.output_names:
                            idx_out = self.model.get_binding_index(name)
                            # 注意：替换xfeat shape(0, 2)-->(1000, 2)
                            if name in self.fixed_output_shapes:
                                shape = self.fixed_output_shapes[name]
                                self.bindings[name].data.resize_(shape)
                            else:
                                self.bindings[name].data.resize_(tuple(self.context.get_binding_shape(idx_out)))

            self.binding_addrs[input_name] = int(im.data_ptr())

        outputs = []
        for output_name in self.output_names:
            output = self.bindings[output_name].data
            self.binding_addrs[output_name] = int(output.data_ptr())
            outputs.append(output)

        if self.stream:
            self.context.execute_async_v2(list(self.binding_addrs.values()), self.stream.cuda_stream)
            self.stream.synchronize()

        else:
            self.context.execute_v2(list(self.binding_addrs.values()))
        return tuple(outputs) if len(outputs) > 1 else outputs[0]

    def from_numpy(self, x):
        """
        将 numpy 数组转换为 PyTorch 张量。

        参数:
            x (np.ndarray): 要转换的数组。

        返回:
            (torch.Tensor): 转换后的张量
        """
        return torch.tensor(x).to(self.device) if isinstance(x, np.ndarray) else x


# 前处理，包括：resize, pad, HWC to CHW，BGR to RGB，归一化，增加维度CHW -> BCHW
def preprocess(img, model_height, model_width):
    """
    Pre-processes the input image.

    Args:
        img (Numpy.ndarray): image about to be processed.

    Returns:
        img_process (Numpy.ndarray): image preprocessed for inference.
        ratio (tuple): width, height ratios in letterbox.
        pad_w (float): width padding in letterbox.
        pad_h (float): height padding in letterbox.
    """
    # Resize and pad input image using letterbox() (Borrowed from Ultralytics)
    
    shape = img.shape[:2]  # original image shape
    new_shape = (model_height, model_width)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    ratio = r, r
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    pad_w, pad_h = (new_shape[1] - new_unpad[0]) / 2, (new_shape[0] - new_unpad[1]) / 2  # wh padding
    if shape[::-1] != new_unpad:  # resize
        img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
        
    top, bottom = int(round(pad_h - 0.1)), int(round(pad_h + 0.1))
    left, right = int(round(pad_w - 0.1)), int(round(pad_w + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))  # 填充
    
    # Transforms: HWC to CHW -> BGR to RGB -> div(255) -> contiguous -> add axis(optional)
    img = np.ascontiguousarray(np.einsum('HWC->CHW', img)[::-1], dtype=np.single) / 255.0
    img_process = img[None] if len(img.shape) == 3 else img
    
    return img_process, ratio, (pad_w, pad_h)


# 后处理，包括：阈值过滤与NMS
def postprocess_int8(preds, im0, ratio, pad_w, pad_h, conf_threshold, iou_threshold):
    """
    Post-process the prediction.

    Args:
        preds (Numpy.ndarray): predictions come from ort.session.run().
        im0 (Numpy.ndarray): [h, w, c] original input image.
        ratio (tuple): width, height ratios in letterbox.
        pad_w (float): width padding in letterbox.
        pad_h (float): height padding in letterbox.
        conf_threshold (float): conf threshold.
        iou_threshold (float): iou threshold.

    Returns:
        boxes (List): list of bounding boxes.
    """
    x = preds  # outputs: predictions (1, 84, 8400)
    x = x.cpu().numpy()
    # Transpose the first output: (Batch_size, xywh_conf_cls, Num_anchors) -> (Batch_size, Num_anchors, xywh_conf_cls)
    # x = np.einsum('bcn->bnc', x)  # (1, 8400, 84)  # 注意：盒子由于通道转换，所以不需要该步骤

    # Predictions filtering by conf-threshold
    x = x[np.amax(x[..., 4:], axis=-1) > conf_threshold]
    # Create a new matrix which merge these(box, score, cls) into one
    # For more details about `numpy.c_()`: https://numpy.org/doc/1.26/reference/generated/numpy.c_.html
    x = np.c_[x[..., :4], np.amax(x[..., 4:], axis=-1), np.argmax(x[..., 4:], axis=-1)]

    # NMS filtering
    # 经过NMS后的值, np.array([[x, y, w, h, conf, cls], ...]), shape=(-1, 4 + 1 + 1)
    x = x[cv2.dnn.NMSBoxes(x[:, :4], x[:, 4], conf_threshold, iou_threshold)]


    # 重新缩放边界框，为画图做准备
    if len(x) > 0:
        # Bounding boxes format change: cxcywh -> xyxy
        x[..., [0, 1]] -= x[..., [2, 3]] / 2
        x[..., [2, 3]] += x[..., [0, 1]]

        # Rescales bounding boxes from model shape(model_height, model_width) to the shape of original image
        x[..., :4] -= [pad_w, pad_h, pad_w, pad_h]
        x[..., :4] /= min(ratio)

        # Bounding boxes boundary clamp
        x[..., [0, 2]] = x[:, [0, 2]].clip(0, im0.shape[1])
        x[..., [1, 3]] = x[:, [1, 3]].clip(0, im0.shape[0])

        return x[..., :6]  # boxes
    else:
        return np.array([])
    
def postprocess_fp16(preds, im0, ratio, pad_w, pad_h, conf_threshold, iou_threshold):
    """
    Post-process the prediction.

    Args:
        preds (Numpy.ndarray): predictions come from ort.session.run().
        im0 (Numpy.ndarray): [h, w, c] original input image.
        ratio (tuple): width, height ratios in letterbox.
        pad_w (float): width padding in letterbox.
        pad_h (float): height padding in letterbox.
        conf_threshold (float): conf threshold.
        iou_threshold (float): iou threshold.

    Returns:
        boxes (List): list of bounding boxes.
    """
    x = preds  # outputs: predictions (1, 84, 8400)
    x = x.cpu().numpy()
    # Transpose the first output: (Batch_size, xywh_conf_cls, Num_anchors) -> (Batch_size, Num_anchors, xywh_conf_cls)
    x = np.einsum('bcn->bnc', x)  # (1, 8400, 84)  # 注意：盒子由于通道转换，所以不需要该步骤

    # Predictions filtering by conf-threshold
    x = x[np.amax(x[..., 4:], axis=-1) > conf_threshold]
    # Create a new matrix which merge these(box, score, cls) into one
    # For more details about `numpy.c_()`: https://numpy.org/doc/1.26/reference/generated/numpy.c_.html
    x = np.c_[x[..., :4], np.amax(x[..., 4:], axis=-1), np.argmax(x[..., 4:], axis=-1)]

    # NMS filtering
    # 经过NMS后的值, np.array([[x, y, w, h, conf, cls], ...]), shape=(-1, 4 + 1 + 1)
    x = x[cv2.dnn.NMSBoxes(x[:, :4], x[:, 4], conf_threshold, iou_threshold)]


    # 重新缩放边界框，为画图做准备
    if len(x) > 0:
        # Bounding boxes format change: cxcywh -> xyxy
        x[..., [0, 1]] -= x[..., [2, 3]] / 2
        x[..., [2, 3]] += x[..., [0, 1]]

        # Rescales bounding boxes from model shape(model_height, model_width) to the shape of original image
        x[..., :4] -= [pad_w, pad_h, pad_w, pad_h]
        x[..., :4] /= min(ratio)

        # Bounding boxes boundary clamp
        x[..., [0, 2]] = x[:, [0, 2]].clip(0, im0.shape[1])
        x[..., [1, 3]] = x[:, [1, 3]].clip(0, im0.shape[0])

        return x[..., :6]  # boxes
    else:
        return np.array([])
    

if __name__ == "__main__":
    # 示例用法：YOLOv8 目标检测
    model = UnifiedTRTModel(
        weights='/data0/backup/all_users/chentuo/ultralytics-main/runs/train_hebing/train_hebing_4/weights/yolov8s_hebing-transd-trends-sim-int8.engine',
        device=torch.device("cuda:0"),
        input_names=['images'],
        output_names=['output0']
    )
    
    times = []
    # 测试求平均推理耗时
    for _ in range(10):
        img0 = cv2.imread('/data0/backup/all_users/chentuo/A_PTQ/hebing_test/images/20240618_sqjy_1.jpg')
        t0 = time.time()
        img, ratio, (pad_w, pad_h) = preprocess(img0, 1280, 1280)
        print('预处理时间：{:.4f}s'.format(time.time() - t0))
        
        # PyTorch 中分配 pinned memory（支持异步传输） 直接传输，速度快一倍
        # img_pinned = img.pin_memory()  # 将 tensor 存入 pinned memory
        # image = img_pinned.to("cuda:0", non_blocking=True)  # 异步传输（non_blocking=True）
        t1 = time.time()
        out = model(torch.from_numpy(img).to('cuda:0'))
        print('det推理时间：{:.4f}s'.format(time.time() - t1))

        out = postprocess(out, img0, ratio, pad_w, pad_h, 0.25, 0.45)
        print('总时间：{:.4f}s'.format(time.time() - t0))

        for (*box, conf, cls_) in out:
            cv2.rectangle(img0, (int(box[0]), int(box[1])), (int(box[2]), int(box[3])),
                          (0, 0, 255), 2, cv2.LINE_AA)
            
    cv2.imwrite(f'res.jpg', img0)

    
 
    
  