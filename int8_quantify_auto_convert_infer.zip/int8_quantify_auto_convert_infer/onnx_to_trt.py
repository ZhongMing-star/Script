
from __future__ import print_function

import argparse
import traceback
import sys
import tensorrt as trt
sys.path.append('./')  # to run '$ python *.py' files in subdirectories
from calibrator import DataLoader, Calibrator


"""
rm yolov8s_calibration.cache
python trt/onnx_to_trt.py --model /home/chentuo/A_code/A_PTQ/hebing-transd-trends-sim.onnx --dtype int8  --img_size_w 1280 --img_size_h 1280 --calib_img_dir /home/chentuo/A_code/A_PTQ/hebing_test --calib_cache hebing_int8.cache  --batch_size 8 --num_calib_batch 12

"""

def _set_excluded_layer_id_precision(network, fp32_layer_ids, fp16_layer_ids):
    """
    Step2: setting the sensitive layer to FP32/FP16
    When generating an INT8 model, it sets excluded layers' precision as fp32 or fp16.

    In detail, this function is only used when generating INT8 TensorRT models. It accepts
    two lists of layer ids: (1). for the layers in fp32_layer_ids, their precision will
    be set as fp32; (2). for those in fp16_layer_ids, their precision will be set as fp16.

    Args:
        network: TensorRT network object.
        fp32_layer_ids (list): List of layer ids. These layers use fp32.
        fp16_layer_ids (list): List of layer ids. These layers use fp16.
    """
    is_mixed_precision = False
    use_fp16_mode = False

    for layer_idx in range(network.num_layers):
        layer = network.get_layer(layer_idx)
        if layer_idx in fp32_layer_ids:
            is_mixed_precision = True
            layer.precision = trt.float32
            layer.set_output_type(0, trt.float32)
        elif layer_idx in fp16_layer_ids:
            is_mixed_precision = True
            use_fp16_mode = True
            layer.precision = trt.float16
            layer.set_output_type(0, trt.float16)
        else:
            layer.precision = trt.int8
            layer.set_output_type(0, trt.int8)

    return network, is_mixed_precision, use_fp16_mode


def build_engine_from_onnx(model_name,
                           dtype,
                           verbose=False,
                           int8_calib=False,
                           calib_loader=None,
                           calib_cache=None,
                           dynamic_shape=False,
                           fp32_layer_names=[],
                           fp16_layer_names=[],
                           ):
    """Initialization routine."""
    if dtype == "int8":
        t_dtype = trt.DataType.INT8
    elif dtype == "fp16":
        t_dtype = trt.DataType.HALF
    elif dtype == "fp32":
        t_dtype = trt.DataType.FLOAT
    else:
        raise ValueError("Unsupported data type: %s" % dtype)

    if trt.__version__[0] < '8':
        print('Exit, trt.version should be >=8. Now your trt version is ', trt.__version__[0])

    network_flags = 1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
    if dtype == "int8" and calib_loader is None:
        print('QAT enabled!')
        network_flags = network_flags | (1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_PRECISION))

    """Build a TensorRT engine from ONNX"""
    TRT_LOGGER = trt.Logger(trt.Logger.VERBOSE) if verbose else trt.Logger()
    with trt.Builder(TRT_LOGGER) as builder, builder.create_network(flags=network_flags) as network, \
            trt.OnnxParser(network, TRT_LOGGER) as parser:
        with open(model_name, 'rb') as model:
            if not parser.parse(model.read()):
                print('ERROR: ONNX Parse Failed')
                for error in range(parser.num_errors):
                    print(parser.get_error(error))
                    return None

        print('Building an engine.  This would take a while...')
        print('(Use "--verbose" or "-v" to enable verbose logging.)')
        config = builder.create_builder_config()
        config.max_workspace_size = 2 << 30
        
        if t_dtype == trt.DataType.HALF:
            config.flags |= 1 << int(trt.BuilderFlag.FP16)

        if t_dtype == trt.DataType.INT8:
            print('trt.DataType.INT8')
            config.flags |= 1 << int(trt.BuilderFlag.INT8)
            config.flags |= 1 << int(trt.BuilderFlag.FP16)

            if int8_calib:
                config.int8_calibrator = Calibrator(calib_loader, calib_cache)
                print('Int8 calibation is enabled.')

            # 新增-某些层强制为fp16/fp32
            layer_idxs_fp32 = []
            layer_idxs_fp16 = []
            ShuffleLayer = []
            # 处理fp16_layer_names为字符串的情况
            if fp16_layer_names and isinstance(fp16_layer_names, str):
                fp16_layer_names = [i.strip() for i in fp16_layer_names.strip().split(' ')]
                print(f'fp16_layer_names: {fp16_layer_names}')
            # 处理fp32_layer_names为字符串的情况
            if fp32_layer_names and isinstance(fp32_layer_names, str):
                fp32_layer_names = [i.strip() for i in fp32_layer_names.strip().split(' ')]
                print(f'fp32_layer_names: {fp32_layer_names}')
            
            for layer_idx in range(network.num_layers):
                layer = network.get_layer(layer_idx)
                for fp16_name in fp16_layer_names:
                    if fp16_name in layer.name:
                        layer_idxs_fp16.append(layer_idx)
                        break
                for fp32_name in fp32_layer_names:
                    if fp32_name in layer.name:
                        layer_idxs_fp32.append(layer_idx)
                        break
                
                # 检查是否是 Shuffle 层-Detect层有几个无法命名的Transpose
                if "Shuffle" in layer.name:
                    print(f"Found Shuffle layer at index {layer_idx}: {layer.name}")
                    ShuffleLayer.append(layer_idx)

            # 只选取ShuffleLayer列表中，值大于layer_idxs_fp16列表中最小的值的值
            if layer_idxs_fp16 and ShuffleLayer:
                min_fp16_idx = min(layer_idxs_fp16)
                filtered_shuffle_layers = [idx for idx in ShuffleLayer if idx > min_fp16_idx]        
                layer_idxs_fp16.extend(filtered_shuffle_layers)

            network, strict_type_constraints, fp16_mode = _set_excluded_layer_id_precision(
                network=network,
                fp32_layer_ids=layer_idxs_fp32,
                fp16_layer_ids=layer_idxs_fp16,
            )

            if strict_type_constraints:
                print('Set STRICT_TYPES')
                config.flags |= 1 << int(trt.BuilderFlag.STRICT_TYPES)

            if fp16_mode:
                print('Set fp16_mode')
                config.flags |= 1 << int(trt.BuilderFlag.FP16)

        if dynamic_shape:
            # You can adjust the shape setting according to the actual situation
            profile = builder.create_optimization_profile()
            profile.set_shape("images", (1, 3, 640, 640), (2, 3, 1280, 1280), (4, 3, 3840, 3840))
            config.add_optimization_profile(profile)

        engine = builder.build_engine(network, config)

        try:
            assert engine
        except AssertionError:
            _, _, tb = sys.exc_info()
            traceback.print_tb(tb)  # Fixed format
            tb_info = traceback.extract_tb(tb)
            _, line, _, text = tb_info[-1]
            raise AssertionError(
                "Parsing failed on line {} in statement {}".format(line, text)
            )

        return engine


def main():
    """Create a TensorRT engine for ONNX-based YOLO."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-v', '--verbose', action='store_true',
        help='enable verbose output (for debugging)')
    parser.add_argument(
        '-m', '--model', type=str, required=True,
        help=('onnx model path'))
    parser.add_argument(
        '-d', '--dtype', type=str, required=True,
        help='one type of int8, fp16, fp32')
    parser.add_argument('--dynamic-shape', action='store_true',
        help='Dynamic shape,  defer specifying some or all tensor dimensions until runtime')
    parser.add_argument(
        '--qat', action='store_true',
        help='whether the onnx model is qat; if it is, the int8 calibrator is not needed')
    
    # If enable int8(not post-QAT model), then set the following
    parser.add_argument('--img_size_w', type=int,
                        default=640, help='image size of model input')
    parser.add_argument('--img_size_h', type=int,
                        default=640, help='image size of model input')
    parser.add_argument('--batch_size', type=int,
                        default=32, help='batch size for training: default 64')
    parser.add_argument('--num_calib_batch', default=6, type=int,
                        help='Number of batches for calibration')
    parser.add_argument('--calib_img_dir', default='../coco/images/train2017', type=str,
                        help='Number of batches for calibration')
    parser.add_argument('--calib_cache', default='./trt/yolov5s_calibration.cache', type=str,
                        help='Path of calibration cache')
    parser.add_argument('--calib_method', default='minmax', type=str,
                        help='Calibration method')

    # 模型精度设置
    parser.add_argument('--fp32_layer_names', type=str, default='',
                        help='该层设为FP32精度')
    parser.add_argument('--fp16_layer_names', type=str, default='model.22 node_of_output0',
                        help='该层设为FP16精度, 默认为YOLOv8s的Detect层model.22和node_of_output0, YOLOv8s-p6的Detect层对应model.30')
    args = parser.parse_args()


    if args.dtype == "int8" and not args.qat:
        calib_loader = DataLoader(args.batch_size, args.num_calib_batch, args.calib_img_dir,
                                  args.img_size_w, args.img_size_h)
        engine = build_engine_from_onnx(args.model, args.dtype, args.verbose,
                              int8_calib=True, calib_loader=calib_loader, calib_cache=args.calib_cache,
                              dynamic_shape=args.dynamic_shape,
                              fp32_layer_names=args.fp32_layer_names, fp16_layer_names=args.fp16_layer_names)
    else:
        engine = build_engine_from_onnx(args.model, args.dtype, args.verbose,
                              dynamic_shape=args.dynamic_shape)

    if engine is None:
        raise SystemExit('ERROR: failed to build the TensorRT engine!')

    engine_path = args.model.replace('.onnx', '.engine')
    if args.dtype == "int8" and not args.qat:
        engine_path = args.model.replace('.onnx', '-int8.engine')

    with open(engine_path, 'wb') as f:
        f.write(engine.serialize())
    print('Serialized the TensorRT engine to file: %s' % engine_path)


if __name__ == '__main__':
    main()
