
import os
import json
import argparse
import cv2
import numpy as np
import torch
import sys
from pycocotools.coco import COCO  # pycocotools 2.0.8
from pycocotools.cocoeval import COCOeval
import time
from PIL import Image

from yolo_trt import UnifiedTRTModel, postprocess_int8, postprocess_fp16, preprocess
from class_param import Algo_class


class Evaluator:
    """Evaluate mAP of YOLO TRT model."""
    def __init__(self, args):
        self.args = args
        self.check_args(self.args)

        self.model_prefix = self.args.model.replace('.trt', '').split('/')[-1]
        self.results_file = 'results_{}.json'.format(self.model_prefix)

        self.model = self.args.model
        self.imgs_dir = self.args.imgs_dir
        self.annotations = self.args.annotations
        self.outpath = self.args.outpath
        self.infer_type = self.args.infer_type
        self.outpath_txt = os.path.join(self.outpath, 'txt_results')
        
        self.conf_thres, self.iou_thres = self.args.conf_thres, self.args.iou_thres
        self.img_size_w = self.args.img_size_w
        self.img_size_h = self.args.img_size_h
        self.jpgs = [j for j in os.listdir(self.imgs_dir) if j.endswith('.jpg')]

        self.algo_class = Algo_class()
        self.categories = self.algo_class.class_dict[self.args.algo_name]
        
        # setup processor
        self.processor = UnifiedTRTModel(
                        weights=self.model,
                        device=torch.device("cuda:0"),
                        input_names=['images'],
                        output_names=['output0']
                        )
        
        # 初始化 COCO 数据结构
        self.data = {
            "images": [],
            "annotations": [],
            "categories": self.categories
            }

    def check_args(self, args):
        """Check and make sure command-line arguments are valid."""
        if not os.path.isdir(args.imgs_dir):
            sys.exit('%s is not a valid directory' % args.imgs_dir)
        if not os.path.isdir(args.annotations):
            sys.exit('%s is not a valid file' % args.annotations)
        if not os.path.isdir(args.outpath):
            os.makedirs(args.outpath, exist_ok=True)
        if not os.path.isdir(os.path.join(args.outpath, 'txt_results')):
            os.makedirs(os.path.join(args.outpath, 'txt_results'), exist_ok=True)


    def generate_results(self, processor, imgs_dir, jpgs, results_file, conf_thres, iou_thres, non_coco, infer_type):
        """Run detection on each jpg and write results to file."""
        results = []

        for image_id, jpg in enumerate(jpgs):
            img0 = cv2.imread(os.path.join(imgs_dir, jpg))
            
            try:
                t0 = time.time()
                img, ratio, (pad_w, pad_h) = preprocess(img0, self.img_size_h, self.img_size_w)
                t1 = time.time() - t0
                
                # PyTorch 中分配 pinned memory（支持异步传输） 直接传输，速度快一倍
                # img_pinned = img.pin_memory()  # 将 tensor 存入 pinned memory
                # image = img_pinned.to("cuda:0", non_blocking=True)  # 异步传输（non_blocking=True）
                t2 = time.time()
                out = self.processor(torch.from_numpy(img).to('cuda:0'))
                t3 = time.time() - t2

                t4 = time.time()
                if infer_type == 'fp16':
                    out = postprocess_fp16(out, img0, ratio, pad_w, pad_h, self.conf_thres, self.iou_thres)
                    t5 = time.time() - t4
                    print('Processing {} images, 预处理时间：{:.4f}s, 推理时间：{:.4f}s, 后处理时间：{:.4f}s, 总时间：{:.4f}s'.format(image_id + 1, t1, t3, t5, time.time() - t0))
                elif infer_type == 'int8':
                    out = postprocess_int8(out, img0, ratio, pad_w, pad_h, self.conf_thres, self.iou_thres)
                    t5 = time.time() - t4
                    print('Processing {} images, 预处理时间：{:.4f}s, 推理时间：{:.4f}s, 后处理时间：{:.4f}s, 总时间：{:.4f}s'.format(image_id + 1, t1, t3, t5, time.time() - t0))
            except:
                print('推理图片失败，路径{}'.format(os.path.join(imgs_dir, jpg)))
                out  = np.array([])
            
            if len(out) > 0:
                for (*box, conf, cls_) in out:
                    cv2.rectangle(img0, (int(box[0]), int(box[1])), (int(box[2]), int(box[3])),
                                (0, 0, 255), 2, cv2.LINE_AA)
                    category_name = self.categories[int(cls_)]['name']
                    cv2.putText(img0, f'{category_name} {conf:.2f}', (int(box[0]), int(box[1]) - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                
                # 新增保存 txt 结果的逻辑
                txt_lines = []
                for p in out.tolist():
                    cls_id = int(p[5])
                    conf = float(p[4])
                    x, y, w, h = p[0], p[1], p[2] - p[0], p[3] - p[1]
                    # 获取原图宽高
                    img_h, img_w = img0.shape[:2]
                    # 转换为归一化坐标
                    x_center = (x + w / 2) / img_w
                    y_center = (y + h / 2) / img_h
                    width = w / img_w
                    height = h / img_h
                    txt_lines.append(f'{cls_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f} {conf:.6f}\n')

                txt_filename = os.path.splitext(jpg)[0] + '.txt'
                txt_path = os.path.join(self.outpath_txt, txt_filename)
                with open(txt_path, 'w') as txt_f:
                    txt_f.writelines(txt_lines)

                for p in out.tolist():
                    x = float(p[0])
                    y = float(p[1])
                    w = float(p[2] - p[0])
                    h = float(p[3] - p[1])
                    results.append({'image_id': int(image_id + 1),
                                'category_id': int(cls_),
                                'bbox': [round(x, 3) for x in [x, y, w, h]],
                                'score': round(p[4], 5)})
            else:
                results.append({'image_id': int(image_id + 1),
                                'category_id': None,
                                'bbox': [round(x, 3) for x in [-1, -1, -1, -1]],
                                'score': None})
            
            cv2.imwrite(os.path.join(self.outpath, jpg), img0)

        with open(os.path.join(self.outpath, results_file), 'w') as f:
            f.write(json.dumps(results, indent=4))

    def yolo_to_coco(self):

        annotation_id = 1
        def get_image_size(image_path):
            with Image.open(image_path) as img:
                return img.width, img.height

        # 遍历图像目录
        for image_id, filename in enumerate(self.jpgs):

            image_path = os.path.join(self.imgs_dir, filename)
            label_name = filename.replace('.jpg', '.txt')
            label_path = os.path.join(self.annotations, label_name)

            image_width, image_height = get_image_size(image_path)

            image_info = {
                "id": int(image_id + 1),
                "width": image_width,
                "height": image_height,
                "file_name": filename
            }
          
            self.data["images"].append(image_info)

            # 检查标签文件是否存在
            if os.path.exists(label_path):
                with open(label_path, 'r') as file:
                    lines = file.readlines()

                for line in lines:
                    parts = line.strip().split()
                    if len(parts) != 5:
                        print(f"⚠️ 警告: 标签 {label_name} 格式错误: {line.strip()}")
                        continue

                    category_id = int(parts[0])
                    x_center = float(parts[1]) * image_width
                    y_center = float(parts[2]) * image_height
                    bbox_width = float(parts[3]) * image_width
                    bbox_height = float(parts[4]) * image_height

                    x_min = int(x_center - bbox_width / 2)
                    y_min = int(y_center - bbox_height / 2)
                    bbox = [x_min, y_min, bbox_width, bbox_height]
                    area = bbox_width * bbox_height

                    annotation_info = {
                        "id": annotation_id,
                        "image_id": int(image_id + 1),
                        "category_id": category_id,
                        "bbox": bbox,
                        "area": area,
                        "iscrowd": 0
                    }
                    self.data["annotations"].append(annotation_info)
                    annotation_id += 1

        output_json_path = os.path.join(self.outpath, 'GroundTruth.json')
        with open(output_json_path, 'w') as json_file:
            json.dump(self.data, json_file, indent=4)

        print(f"✅ 转换完成: {output_json_path}")
        self.GroundTruth_path = output_json_path

    def infer(self):
        self.generate_results(self.processor, self.imgs_dir, self.jpgs, self.results_file, self.conf_thres, self.iou_thres, non_coco=False, infer_type=self.infer_type)

    def evaluate(self):
        self.generate_results(self.processor, self.imgs_dir, self.jpgs, self.results_file, self.conf_thres, self.iou_thres, non_coco=False, infer_type=self.infer_type)

        # Run COCO mAP evaluation
        if os.path.exists(self.GroundTruth_path) and os.path.exists(os.path.join(self.outpath, self.results_file)):
            try:
                cocoGt = COCO(self.GroundTruth_path)
                cocoDt = cocoGt.loadRes(os.path.join(self.outpath, self.results_file))
                imgIds = sorted(cocoGt.getImgIds())
                cocoEval = COCOeval(cocoGt, cocoDt, 'bbox')
                cocoEval.params.imgIds = imgIds
                cocoEval.evaluate()
                cocoEval.accumulate()
                cocoEval.summarize()
            except:
                print('COCO评估失败')
        else:
            print('未找到GroundTruth.json文件或results.json文件')   

def parse_args():
    """Parse input arguments."""
    desc = 'Evaluate mAP of YOLO TRT model'
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument(
        '-m', '--model', type=str, default='/data2/AI_box_int8_quantify_data/site_safety/AI_box_int8_quantify_res/trt_engine/yolov8s_aqm_fgy-int8.engine',
        help=('trt model path'))
    parser.add_argument(
        '--imgs_dir', type=str, default='/data2/AI_box_int8_quantify_data/site_safety/test_images',
        help='directory of validation images')
    parser.add_argument(
        '--annotations', type=str, default='/data2/AI_box_int8_quantify_data/site_safety/test_gt_labels',
        help='groundtruth annotations')
    parser.add_argument(
        '--outpath', type=str, default="/data2/AI_box_int8_quantify_data/site_safety/res",
        help='output path')
    parser.add_argument(
        '--infer_type', type=str, default='int8', choices=['fp16', 'int8'], 
        help='推理类型')
    parser.add_argument(
        '--img_size_w', type=int, default=1536, help='image size width')
    parser.add_argument(
        '--img_size_h', type=int, default=864, help='image size height')
    parser.add_argument(
        '--conf_thres', type=float, default=0.25,
        help='object confidence threshold')
    parser.add_argument(
        '--iou_thres', type=float, default=0.6,
        help='IOU threshold for NMS')
    parser.add_argument(
        '--exec_type', type=str, default='infer',
        help='eval or infer')
    parser.add_argument(
        '--algo_name', type=str, required=True,
        help='detect algo name')
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = parse_args()
    evaluator = Evaluator(args)

    if args.exec_type == 'eval':
        evaluator.yolo_to_coco()   
        evaluator.evaluate()
    else:
        evaluator.infer()

     

