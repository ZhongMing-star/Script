# Int8_quantify_auto_convert_infer
1、.项目介绍

该项目实现了自动量化模型的功能，包括模型的量化、转换和推理及评估。

2、.项目说明

项目结构树说明：
```
├── Int8_quantify_auto_convert_infer
│   ├── cal_pr.py：模型评估脚本
│   ├── calibrator.py：模型量化类
│   ├── class_param.py：模型参数类
│   ├── eval_yolo_trt.py：模型推理脚本
│   ├── export_jetson_onnx.py：导出onnx模型脚本
│   ├── json_to_yolo.py：json文件转yolo格式脚本
│   ├── onnx_to_trt.py：onnx模型转trt模型脚本
│   ├── pt_to_trt.py：pt模型转trt模型脚本
│   ├── yolo_trt.py：trt模型推理脚本
│   ├── run_pipeline.py：一键自动化运行脚本
│   └── README.md：项目说明文件
```

3、.项目运行

3.1 运行一键自动化脚本：

1）如果标签文件是txt格式的，使用如下命令：
部分量化追加参数【对应YOLOv8s-Detect层，其他模型请根据实际情况修改，多层以空格隔开】，如： --fp16_layer_names 'model.22 node_of_output0'

```
CUDA_VISIBLE_DEVICES=2 python run_pipeline.py --pt_model /data2/AI_box_int8_quantify_data/site_safety/yolov8s_aqm_fgy.pt --fp16_trt_model /data0/work/DGDeploy/models_v1.9/site_safety_trt/model.trt --calib_img_dir /data2/AI_box_int8_quantify_data/site_safety/calibration_images/ --test_img_dir /data2/AI_box_int8_quantify_data/site_safety/test_images/ --gt_label_dir /data2/AI_box_int8_quantify_data/site_safety/test_gt_labels/ --calibration_labels_dir /data2/AI_box_int8_quantify_data/site_safety/test_gt_labels/ --algo_name site_safety --width_int8 1536 --height_int8 864 --width_fp16 1536 --height_fp16 1536 --output_root /data2/AI_box_int8_quantify_data/site_safety/res 
```

2）如果标签文件是json格式的，使用如下命令：

```
CUDA_VISIBLE_DEVICES=2 python run_pipeline.py --pt_model /data2/AI_box_int8_quantify_data/site_safety/yolov8s_aqm_fgy.pt --fp16_trt_model /data0/work/DGDeploy/models_v1.9/site_safety_trt/model.trt --calib_img_dir /data2/AI_box_int8_quantify_data/site_safety/calibration_images/ --test_img_dir /data2/AI_box_int8_quantify_data/site_safety/test_images/ --gt_label_dir /data2/AI_box_int8_quantify_data/site_safety/test_gt_labels/ --calibration_labels_dir /data2/AI_box_int8_quantify_data/site_safety/test_gt_labels/ --algo_name site_safety --classes /home/xxf/codes/AI_box_int8_quantify/classes.txt --width_int8 1536 --height_int8 864 --width_fp16 1536 --height_fp16 1536 --output_root /data2/AI_box_int8_quantify_data/site_safety/res 
```

3.2 参数介绍

```python
--pt_model：对应的待转换的原始pt模型路径（不同模型，该参数需要修改）
--fp16_trt_model：对应的东高fp16模型路径（不同模型，该参数需要修改）
--calib_img_dir：校准数据集路径（不同模型，该参数需要修改）
--test_img_dir：测试数据集（不同模型，该参数需要修改）
--gt_label_dir：测试数据集对应的已打标的标签集（不同模型，该参数需要修改）
--calibration_labels_dir：校准数据集对应的标签文件（该项视自己情况而定，如果不需要统计，写 ' ' 即可）
--algo_name：待测试的模型的名字（不同模型，该参数需要修改）
--classes：当需要进行json标签转txt标签时，加载的类别定义标签文件
--width_int8：转换后的int8模型的输入宽
--height_int8：转换后的int8模型的输入高
注：一般训练的尺寸是1536*1536，就写width*height = 1536*864
训练尺寸是1280*1280，就写width*height = 1280*1280

--width_fp16：转换后的fp16模型的输入宽
--height_fp16：转换后的fp16模型的输入高
--output_root：输出结果保存路径（视自己情况而定）

```