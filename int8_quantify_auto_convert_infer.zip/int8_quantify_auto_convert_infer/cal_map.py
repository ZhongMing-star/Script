import os
import numpy as np
from collections import defaultdict
from matplotlib import pyplot as plt
import argparse
from class_param import Algo_class

# 解析命令行参数
def parse_args():
    parser = argparse.ArgumentParser(description='计算目标检测精度指标')
    parser.add_argument('--annotation_dir', type=str, required=True, help='GT标签目录路径（仅支持txt格式）')
    parser.add_argument('--prediction_dir', type=str, required=True, help='预测结果txt目录路径')
    parser.add_argument('--conf_thres', type=float, default=0.25, help='置信度阈值')
    parser.add_argument('--algo_name', type=str, required=True, help='detect algo name')
    return parser.parse_args()

def parse_yolo_label(file_path):
    """解析YOLO格式的标签文件（class_id x_center y_center width height）"""
    labels = []
    if not os.path.exists(file_path):
        return labels
    
    with open(file_path, 'r') as f:
        for line in f.readlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            class_id = int(parts[0])
            x_center = float(parts[1])
            y_center = float(parts[2])
            width = float(parts[3])
            height = float(parts[4])
            labels.append({
                'class_id': class_id,
                'bbox': (x_center, y_center, width, height)
            })
    return labels

def parse_filtered_prediction(file_path):
    """解析已过滤置信度的YOLO预测文件（包含置信度字段）"""
    predictions = []
    if not os.path.exists(file_path):
        return predictions
    
    with open(file_path, 'r') as f:
        for line in f.readlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            # 假设预测文件格式：class_id x_center y_center width height confidence（共6个字段）
            if len(parts) < 6:
                continue  # 跳过格式错误的行
            class_id = int(parts[0])
            x_center = float(parts[1])
            y_center = float(parts[2])
            width = float(parts[3])
            height = float(parts[4])
            # 读取第6个字段作为真实置信度（关键修改）
            confidence = float(parts[5])  # 取消注释并读取真实置信度
            # confidence = 1.0  # 注释掉占位值
            predictions.append({
                'class_id': class_id,
                'bbox': (x_center, y_center, width, height),
                'confidence': confidence
            })
    return predictions

def bbox_to_xyxy(bbox):
    """将YOLO格式的bbox (x_center, y_center, width, height) 转换为 (x1, y1, x2, y2)"""
    x_center, y_center, width, height = bbox
    x1 = x_center - width / 2
    y1 = y_center - height / 2
    x2 = x_center + width / 2
    y2 = y_center + height / 2
    return (x1, y1, x2, y2)

def iou(bbox1, bbox2):
    """计算两个边界框的交并比(IoU)"""
    x1_1, y1_1, x2_1, y2_1 = bbox_to_xyxy(bbox1)
    x1_2, y1_2, x2_2, y2_2 = bbox_to_xyxy(bbox2)
    
    # 计算交集区域
    inter_x1 = max(x1_1, x1_2)
    inter_y1 = max(y1_1, y1_2)
    inter_x2 = min(x2_1, x2_2)
    inter_y2 = min(y2_1, y2_2)
    
    inter_area = max(0, inter_x2 - inter_x1) * max(0, inter_y2 - inter_y1)
    
    # 计算每个边界框的面积
    area1 = (x2_1 - x1_1) * (y2_1 - y1_1)
    area2 = (x2_2 - x1_2) * (y2_2 - y1_2)
    
    # 计算并集面积
    union_area = area1 + area2 - inter_area
    
    # 计算IoU
    if union_area == 0:
        return 0.0
    return inter_area / union_area

def evaluate_filtered_yolo(predictions_dir, labels_dir, class_names=None, iou_threshold=0.5):
    """
    评估已过滤置信度的YOLO预测结果
    
    参数:
        predictions_dir: 预测结果文件夹路径（已过滤置信度）
        labels_dir: 标签文件夹路径
        class_names: 类别名称列表，索引对应class_id
        iou_threshold: IoU阈值，默认为0.5 (用于计算mAP50)
    """
    # 获取所有图片文件名（不含扩展名）
    image_files = set()
    for filename in os.listdir(labels_dir):
        if filename.endswith('.txt'):
            image_files.add(os.path.splitext(filename)[0])
    
    # 初始化统计数据
    class_metrics = defaultdict(lambda: {'tp': 0, 'fp': 0, 'fn': 0})
    all_predictions = defaultdict(list)  # 按类别存储所有预测
    total_ground_truth = defaultdict(int)  # 按类别存储总真实目标数
    pr_curves = defaultdict(dict)  # 新增：存储PR曲线数据 (class_id: {'precisions': [], 'recalls': []})
    
    # 处理每个图像
    for image_id in image_files:
        # 加载标签和预测
        label_path = os.path.join(labels_dir, f'{image_id}.txt')
        pred_path = os.path.join(predictions_dir, f'{image_id}.txt')
        
        ground_truths = parse_yolo_label(label_path)
        predictions = parse_filtered_prediction(pred_path)
        
        # 标记已匹配的真实目标
        matched_gt = [False] * len(ground_truths)
        
        # 统计每个类别的真实目标数量
        for gt in ground_truths:
            class_id = gt['class_id']
            total_ground_truth[class_id] += 1
        
        # 处理预测结果（已过滤置信度，按文件中出现顺序处理）
        for pred in predictions:
            class_id = pred['class_id']
            pred_bbox = pred['bbox']
            
            # 保存所有预测用于计算AP（用占位置信度）
            all_predictions[class_id].append({
                'confidence': pred['confidence'],  # 已过滤，这里用占位值
                'image_id': image_id,
                'matched': False
            })
            
            # 查找最佳匹配的真实目标
            best_iou = 0
            best_gt_idx = -1
            
            for i, gt in enumerate(ground_truths):
                if not matched_gt[i] and gt['class_id'] == class_id:
                    current_iou = iou(pred_bbox, gt['bbox'])
                    if current_iou > best_iou and current_iou > iou_threshold:
                        best_iou = current_iou
                        best_gt_idx = i
            
            # 判断是TP还是FP
            if best_gt_idx != -1:
                matched_gt[best_gt_idx] = True
                class_metrics[class_id]['tp'] += 1
                all_predictions[class_id][-1]['matched'] = True
            else:
                class_metrics[class_id]['fp'] += 1
        
        # 统计未匹配的真实目标（FN）
        for i, gt in enumerate(ground_truths):
            if not matched_gt[i]:
                class_id = gt['class_id']
                class_metrics[class_id]['fn'] += 1
    
    # 计算每个类别的精确率、召回率和F1分数
    metrics = {}
    aps = {}
    
    for class_id in class_metrics:
        tp = class_metrics[class_id]['tp']
        fp = class_metrics[class_id]['fp']
        fn = class_metrics[class_id]['fn']
        
        # 计算精确率
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        
        # 计算召回率
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        
        # 计算F1分数
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
        
        metrics[class_id] = {
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'tp': tp,
            'fp': fp,
            'fn': fn
        }
        
        # 计算AP（使用全局排序的预测结果）
        if class_id in all_predictions and len(all_predictions[class_id]) > 0:
            # 关键修改：将所有图像的预测结果按置信度降序排序（全局排序）
            sorted_preds = sorted(
                all_predictions[class_id],
                key=lambda p: p['confidence'],  # 按置信度排序
                reverse=True  # 降序（高置信度优先）
            )
            
            # 计算PR曲线（基于全局排序的预测结果）
            precisions = []
            recalls = []
            tp_count = 0
            fp_count = 0
            total_gt = total_ground_truth.get(class_id, 0)
            
            # # 新增：添加PR曲线起点 (0.0, 1.0)
            # if total_gt > 0:
            #     precisions.append(1.0)
            #     recalls.append(0.0)

            for pred in sorted_preds:
                if pred['matched']:
                    tp_count += 1
                else:
                    fp_count += 1
                
                prec = tp_count / (tp_count + fp_count) if (tp_count + fp_count) > 0 else 0.0
                rec = tp_count / total_gt if total_gt > 0 else 0.0
                
                precisions.append(prec)
                recalls.append(rec)
            
            # 新增：添加PR曲线终点 (1.0, 0.0)，确保覆盖完整召回率区间
            if total_gt > 0:
                recalls.append(1.0)
                precisions.append(0.0)

            # 计算AP（11点插值法，保持不变）
            # ======== 核心修改：YOLOv8风格AP计算 ========
            if total_gt > 0 and len(precisions) > 0:
                # 1. 添加边界哨兵值（YOLOv8标准）
                mrec = np.concatenate(([0.0], recalls))  # 召回率：[0] + 原始
                mpre = np.concatenate(([1.0], precisions))  # 精确率：[1] + 原始
                
                # 2. 计算精度包络线（确保非递增）
                mpre = np.flip(np.maximum.accumulate(np.flip(mpre)))  # 翻转后累积最大值，再翻转回原顺序
                
                # 3. 积分计算AP（支持两种方法）
                method = 'interp'  # 'interp' (101点插值，COCO标准) 或 'continuous' (连续积分)
                if method == 'interp':
                    x = np.linspace(0, 1, 101)  # 101点插值（YOLOv8默认）
                    ap = np.trapz(np.interp(x, mrec, mpre), x)  # 梯形积分法
                else:  # 'continuous'
                    # 找到召回率变化的点，计算矩形面积之和
                    i = np.where(mrec[1:] != mrec[:-1])[0]
                    ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
            else:
                ap = 0.0  # 无真实目标或无预测时，AP为0
          
            aps[class_id] = ap

            # 新增：保存当前类别的PR曲线数据
            pr_curves[class_id] = {
                'precisions': precisions,
                'recalls': recalls
            }
    
    # 计算mAP50
    map50 = sum(aps.values()) / len(aps) if aps else 0.0
    
    # 整理结果
    result = {
        'class_metrics': metrics,
        'ap50': aps,
        'map50': map50,
        'class_names': class_names,
        'pr_curves': pr_curves  # 新增：PR曲线数据
    }
    
    return result

def print_evaluation_result(result, conf):
    """打印评估结果"""
    class_metrics = result['class_metrics']
    aps = result['ap50']
    map50 = result['map50']
    class_names = result['class_names']
    
    print("=" * 72)
    print(f"评估结果（已过滤置信度阈值={conf}）")
    print(f"mAP50: {map50:.4f}")
    print("=" * 72)
    print(f"{'Class':<14} {'Precision':<10} {'Recall':<11} {'F1':<8} {'AP50':<9} {'TP':<5} {'FP':<4} {'FN':<5}")
    print("-" * 72)
    
    for class_id in sorted(class_metrics.keys()):
        metrics = class_metrics[class_id]
        ap = aps.get(class_id, 0.0)
        
        class_name = f"Class {class_id}"
        if class_names and class_id < len(class_names):
            class_name = class_names[class_id]
        
        print(f"{class_name:<15} {metrics['precision']:.4f}    {metrics['recall']:.4f}    {metrics['f1']:.4f}    {ap:.4f}    {metrics['tp']:<5} {metrics['fp']:<5} {metrics['fn']:<5}")
    
    print("=" * 72)



# 新增：绘制PR曲线函数
def plot_pr_curves(result, output_path=None):
    """
    绘制所有类别的Precision-Recall曲线
    
    参数:
        result: 评估函数返回的结果字典
        output_path: 图像保存路径（None则直接显示）
    """
    pr_curves = result['pr_curves']
    class_names = result['class_names']
    map50 = result['map50']
    
    plt.figure(figsize=(10, 8))
    
    # 绘制每个类别的PR曲线
    for class_id in pr_curves:
        data = pr_curves[class_id]
        precisions = data['precisions']
        recalls = data['recalls']
        
        # 获取类别名称
        class_name = f"Class {class_id}"
        if class_names and class_id < len(class_names):
            class_name = class_names[class_id]
        
        # 绘制PR曲线
        plt.plot(recalls, precisions, marker='.', label=f'{class_name} (AP={result["ap50"][class_id]:.3f})')
    
    # 图表配置
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title(f'Precision-Recall Curves (mAP50={map50:.3f})', fontsize=14)
    plt.grid(alpha=0.3)
    plt.legend(loc='lower left', fontsize=10)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    
    # 保存或显示图像
    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"PR曲线已保存至: {output_path}")
    else:
        plt.show()
    
    plt.close()

if __name__ == "__main__":
    args = parse_args()
    # 配置路径 - 请根据实际情况修改
    PREDICTIONS_DIR = args.prediction_dir  # 已过滤置信度的预测结果文件夹
    LABELS_DIR = args.annotation_dir # 标签文件夹
    conf = args.conf_thres
    # 类别名称列表 - 请根据实际情况修改
    algo_class = Algo_class()
    CLASS_NAMES = [item['name'] for item in algo_class.class_dict[args.algo_name]]  # 示例类别，需与你的class_id对应
    
    try:
        # 执行评估（IoU=0.5即mAP50）
        evaluation_result = evaluate_filtered_yolo(
            predictions_dir=PREDICTIONS_DIR,
            labels_dir=LABELS_DIR,
            class_names=CLASS_NAMES,
            iou_threshold=0.5
        )
        
        # 打印结果
        print_evaluation_result(evaluation_result, conf)

        # 新增：绘制并保存PR曲线（如需显示图像，将output_path设为None）
        plot_pr_curves(evaluation_result, output_path=os.path.join(os.path.dirname(PREDICTIONS_DIR), 'pr_curves.png'))
    except Exception as e:
        print('Cal map error:', e)