class Algo_class:
    def __init__(self):
        self.class_dict = {'site_safety': [{"id": 0, "name": "fgy"}, {"id": 1, "name": "aqm"}, {"id": 2, "name": "person"}],
                           'engineering_vehicle': [{"id": 0, "name": "kz_ztc"}, {"id": 1, "name": "wsg_ztc"}, {"id": 2, "name": "sg_ztc"}, {"id": 3, "name": "cc"}, {"id": 4, "name": "wjj"}, {"id": 5, "name": "ttj"}],
                           'construction_safety': [{"id": 0, "name": "ysfwwj"}, {"id": 1, "name": "td"}, {"id": 2, "name": "msqzj"}, {"id": 3, "name": "wdjs"}],
                           'waters_person': [{"id": 0, "name": "person"}, {"id": 1, "name": "swim_person"}, {"id": 2, "name": "daodi_person"}, {"id": 3, "name": "diaoyu_person"}, {"id": 4, "name": "smpfw"}, {"id": 5, "name": "smdmjzw"}, {"id": 6, "name": "byc"}],
                           'road_security': [{"id": 0, "name": "waterlogging"}, {"id": 1, "name": "normal_banner"}, {"id": 2, "name": "abnormal_banner"}, {"id": 3, "name": "withered_tree"}, {"id": 4, "name": "tree"}, {"id": 5, "name": "ztc"}, {"id": 6, "name": "wjj"}, {"id": 7, "name": "ttj"}, {"id": 8, "name": "ylj"}, {"id": 9, "name": "sm"}, {"id": 10, "name": "fzt"}, {"id": 11, "name": "lbt"}, {"id": 12, "name": "lbdt"}, {"id": 13, "name": "lbzyp"}, {"id": 14, "name": "zy"}],
                           'fire_smoke': [{"id": 0, "name": "fire"}, {"id": 1, "name": "smoke"}],
                           'person_car_boat': [{"id": 0, "name": "person"}, {"id": 1, "name": "car"}, {"id": 2, "name": "boat"}]
                           }