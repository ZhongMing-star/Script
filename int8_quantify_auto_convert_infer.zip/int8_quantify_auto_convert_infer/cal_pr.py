# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
from collections import defaultdict
import argparse
import tempfile
import shutil
import sys
import logging  # 新增：导入logging模块
from typing import Dict, List, Tuple, Optional
from json_to_yolo import CustomToYoloConverter

# 适配Windows 11的中文字体配置
plt.rcParams["font.family"] = ["simsun"]
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

# 解析命令行参数
def parse_args():
    parser = argparse.ArgumentParser(description='计算目标检测精度指标')
    parser.add_argument('--annotation_dir', type=str, required=True, help='GT标签目录路径（支持txt格式和json格式）')
    parser.add_argument('--prediction_dir', type=str, required=True, help='预测结果txt目录路径')
    parser.add_argument('--calibration_labels_dir', type=str, required=True, help='校准标签目录路径（支持txt格式和json格式）')
    parser.add_argument('--conf_thres', type=float, default=0.5, help='置信度阈值')
    parser.add_argument('--iou_thres', type=float, default=0.5, help='IOU阈值')
    parser.add_argument('--classes', type=str, default='', required=False, help='类别定义文件路径（可选，存在时用于JSON转TXT）') 
    return parser.parse_args()

# 新增：配置参数 dataclass
from dataclasses import dataclass
@dataclass
class EvalConfig:
    annotation_dir: str
    prediction_dir: str
    calibration_labels_dir: str
    conf_thres: float
    iou_thres: float
    classes_path: str

# 新增：评估结果数据结构
@dataclass
class EvaluationResult:
    class_stats: Dict[int, Dict[str, int]]
    calibration_counts: Dict[int, int]
    metrics: List[List[float]]
    all_classes: List[int]

# 主评估类
class EvaluationPipeline:
    def __init__(self, config: EvalConfig):
        self.config = config
        self.logger = self._setup_logger()
        self.temp_dirs = []  # 跟踪临时目录
        self.converter = None  # 初始化为None

    def _setup_logger(self):
        logger = logging.getLogger('EvaluationPipeline')
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

    def _is_directory_empty(self, dir_path: str, file_extensions: List[str] = ['.txt', '.json']) -> bool:
        dir_path = Path(dir_path)
        if not dir_path.exists() or not dir_path.is_dir():
            return True
        for ext in file_extensions:
            if list(dir_path.glob(f'*{ext}')):
                return False
        return True

    def _convert_json_to_txt(self, input_dir: str) -> Tuple[str, Optional[str]]:
        # 新增：检查classes_path有效性
        if not self.config.classes_path:
            self.logger.info("未提供类别定义标签文件，加载的标签文件是txt格式，不需要进行JSON转TXT步骤")
            return input_dir, None
        classes_path = Path(self.config.classes_path)
        if not classes_path.exists():
            self.logger.error(f"类别定义文件不存在: {self.config.classes_path}")
            return input_dir, None
        # 仅当路径有效时实例化转换器
        if self.converter is None:
            self.converter = CustomToYoloConverter(str(classes_path))

        input_path = Path(input_dir)
        json_files = list(input_path.glob('*.json'))
        if not json_files:
            return input_dir, None
        temp_dir = tempfile.mkdtemp(prefix='yolo_temp_')
        self.converter.batch_convert(str(input_path), temp_dir)
        self.logger.info(f"已将JSON标签转换为TXT格式，保存在临时目录: {temp_dir}")
        return temp_dir, temp_dir

    def load_annotations(self, dir_path: str) -> Dict[str, Dict[int, List[List[float]]]]:
        annotation = defaultdict(lambda: defaultdict(list))
        ann_files = Path(dir_path).glob('*.txt')
        for ann_file in ann_files:
            filename = Path(ann_file).name
            with open(ann_file, 'r') as fin:
                for line in fin:
                    line_list = line.split()
                    x_center, y_center, w, h = map(float, line_list[1:5])
                    x_min = x_center - w / 2
                    y_min = y_center - h / 2
                    x_max = x_center + w / 2
                    y_max = y_center + h / 2
                    class_id = int(line_list[0])
                    annotation[filename][class_id].append([x_min, y_min, x_max, y_max, class_id])
        return annotation

    def calculate_metrics(self, annotations: Dict, predictions: Dict) -> Tuple[Dict, List, List]:
        all_classes = set()
        for file_anns in annotations.values():
            all_classes.update(file_anns.keys())
        for file_preds in predictions.values():
            all_classes.update(file_preds.keys())
        all_classes = sorted(all_classes)

        class_stats = {cls: {'correct': 0, 'pred_total': 0, 'ann_total': 0} for cls in all_classes}

        for filename in annotations.keys():
            ann_by_cls = annotations[filename]
            pred_by_cls = predictions.get(filename, defaultdict(list))

            for cls, anns in ann_by_cls.items():
                class_stats[cls]['ann_total'] += len(anns)

            for cls, preds in pred_by_cls.items():
                class_stats[cls]['pred_total'] += len(preds)
                anns = ann_by_cls.get(cls, [])
                matched_anns = set()
                for pred in preds:
                    pred_rect = pred[:4]
                    for ann_idx, ann in enumerate(anns):
                        if ann_idx in matched_anns:
                            continue
                        ann_rect = ann[:4]
                        if self.calculate_iou(pred_rect, ann_rect) >= self.config.iou_thres:
                            class_stats[cls]['correct'] += 1
                            matched_anns.add(ann_idx)
                            break

        metrics = []
        self.logger.info(f"===== 推理评估结果: =====")
        for cls in all_classes:
            stats = class_stats[cls]
            correct, pred_total, ann_total = stats['correct'], stats['pred_total'], stats['ann_total']
            precision = correct / pred_total if pred_total != 0 else 0.0
            recall = correct / ann_total if ann_total != 0 else 0.0
            pr = 0.5 * precision + 0.5 * recall
            metrics.append([precision, recall, pr])
            self.logger.info(f"类别 {cls}:")
            self.logger.info(f"Precision: {precision:.4f} (正确预测数: {correct}, 总预测数: {pred_total})")
            self.logger.info(f"Recall: {recall:.4f} (正确预测数: {correct}, 总标注数: {ann_total})")
            self.logger.info(f"识别率pr: {pr:.4f}\n")
        return class_stats, metrics, all_classes

    def calculate_iou(self, rect1, rect2):
        overlap_x1 = max(rect1[0], rect2[0])
        overlap_y1 = max(rect1[1], rect2[1])
        overlap_x2 = min(rect1[2], rect2[2])
        overlap_y2 = min(rect1[3], rect2[3])
        if overlap_x2 - overlap_x1 <= 0 or overlap_y2 - overlap_y1 <= 0:
            return 0.0
        iou_area = (overlap_x2 - overlap_x1) * (overlap_y2 - overlap_y1)
        union_area = (rect1[2] - rect1[0]) * (rect1[3] - rect1[1]) + (rect2[2] - rect2[0]) * (rect2[3] - rect2[1]) - iou_area
        return iou_area / union_area

    def analyze_calibration_data(self, dir_path: str) -> Dict[int, int]:
        calibration_class_counts = defaultdict(int)
        calib_dir = Path(dir_path)
        calib_files = list(calib_dir.glob('*.txt'))
        if not calib_files:
            self.logger.info("⚠️ 校准集标签文件夹为空，跳过统计...")
            return calibration_class_counts

        for calib_file in calib_files:
            with open(calib_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split()
                    if len(parts) < 5:
                        continue
                    try:
                        class_id = int(parts[0])
                        calibration_class_counts[class_id] += 1
                    except (ValueError, IndexError):
                        continue

        self.logger.info("\n===== 校准数据集类别矩形框统计 =====")
        for class_id in sorted(calibration_class_counts.keys()):
            self.logger.info(f"类别 {class_id}: {calibration_class_counts[class_id]} 个矩形框")
        self.logger.info("====================================\n")
        return calibration_class_counts

    def visualize_results(self, classes: List[int], metrics: List[List[float]]) -> None:
        n_classes = len(classes)
        bar_width = 0.2
        x = np.arange(n_classes)
        x_p, x_r, x_pr = x - bar_width, x, x + bar_width

        p_values = [m[0] for m in metrics]
        r_values = [m[1] for m in metrics]
        pr_values = [m[2] for m in metrics]

        plt.figure(figsize=(10 + n_classes * 0.5, 6))

        bars_p = plt.bar(x_p, p_values, width=bar_width, label='Precision (P)', color='#1f77b4', edgecolor='black')
        bars_r = plt.bar(x_r, r_values, width=bar_width, label='Recall (R)', color='#2ca02c', edgecolor='black')
        bars_pr = plt.bar(x_pr, pr_values, width=bar_width, label='识别率pr', color='#ff7f0e', edgecolor='black')

        plt.ylim(0, 1.1)
        plt.yticks(np.arange(0, 1.01, 0.05))
        plt.xticks(x, classes)
        plt.xlabel('类别ID')
        plt.ylabel('指标值')
        plt.title('各类别Precision、Recall及识别率对比')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.legend()

        font_size = max(8, min(12, int(bar_width * 30)))

        def add_labels(bars, values):
            for bar, value in zip(bars, values):
                height = bar.get_height()
                label = f'{value:.3f}'
                plt.text(bar.get_x() + bar.get_width() / 2, height + 0.01, label, ha='center', va='bottom', color='red', fontsize=font_size)

        add_labels(bars_p, p_values)
        add_labels(bars_r, r_values)
        add_labels(bars_pr, pr_values)

        plt.tight_layout()
        plt.show()

    def run_pipeline(self) -> EvaluationResult:
        try:
            if self._is_directory_empty(self.config.annotation_dir):
                raise ValueError(f"GT标签目录为空: {self.config.annotation_dir}")

            ann_dir, ann_temp = self._convert_json_to_txt(self.config.annotation_dir)
            calib_dir, calib_temp = self._convert_json_to_txt(self.config.calibration_labels_dir)
            self.temp_dirs = [d for d in [ann_temp, calib_temp] if d]

            annotations = self.load_annotations(ann_dir)
            predictions = self.load_annotations(self.config.prediction_dir)

            calib_counts = self.analyze_calibration_data(calib_dir)

            class_stats, metrics, all_classes = self.calculate_metrics(annotations, predictions)

            self.visualize_results(all_classes, metrics)

            return EvaluationResult(class_stats, calib_counts, metrics, all_classes)

        finally:
            for temp_dir in self.temp_dirs:
                if temp_dir and Path(temp_dir).exists():
                    shutil.rmtree(temp_dir)
                    self.logger.info(f"已清理临时目录: {temp_dir}")

# 简化main函数
def main():
    args = parse_args()
    config = EvalConfig(
        annotation_dir=args.annotation_dir,
        prediction_dir=args.prediction_dir,
        calibration_labels_dir=args.calibration_labels_dir,
        conf_thres=args.conf_thres,
        iou_thres=args.iou_thres,
        classes_path=args.classes
    )

    evaluator = EvaluationPipeline(config)
    try:
        result = evaluator.run_pipeline()
        evaluator.logger.info("评估流程已成功完成")
    except Exception as e:
        evaluator.logger.error(f"评估过程中发生错误: {str(e)}", exc_info=True)
        sys.exit(1)

if __name__ == '__main__':
    main()