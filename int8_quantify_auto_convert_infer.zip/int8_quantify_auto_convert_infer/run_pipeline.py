import argparse
import subprocess
import os
import shutil
import json  # 新增：导入json模块用于验证类别配置格式

def parse_args():
    parser = argparse.ArgumentParser(description='YOLO模型量化-推理-评估一键流程')
    # 输入参数
    parser.add_argument('--pt_model', required=True, help='输入的PyTorch模型路径(.pt)')
    parser.add_argument('--fp16_trt_model', required=True, help='输入的FP16 TRT模型路径(.trt)')
    parser.add_argument('--calib_img_dir', required=True, help='INT8量化校准图像目录')
    parser.add_argument('--test_img_dir', required=True, help='测试图像目录')
    parser.add_argument('--gt_label_dir', required=True, help='Ground Truth标签目录')
    parser.add_argument('--calibration_labels_dir', required=True, help='校准标签目录')
    # 配置参数
    parser.add_argument('--width_int8', type=int, default=1280, help='int8模型输入宽度')
    parser.add_argument('--height_int8', type=int, default=1280, help='int8模型输入高度')
    parser.add_argument('--width_fp16', type=int, default=1280, help='fp16模型输入宽度')
    parser.add_argument('--height_fp16', type=int, default=1280, help='fp16模型输入高度')
    parser.add_argument('--batch_size', type=int, default=32, help='校准批大小')
    parser.add_argument('--conf_thres', type=float, default=0.5, help='推理置信度阈值')
    parser.add_argument('--iou_thres', type=float, default=0.5, help='NMS IOU阈值')
    # 新增：类别配置参数
    parser.add_argument('--algo_name', type=str, required=True, help='detect algo name')
    parser.add_argument('--classes', type=str, default='', required=False, help='类别定义文件路径（可选，存在时用于JSON转TXT）')
    # 输出参数
    parser.add_argument('--output_root', default='./pipeline_results', help='结果输出根目录')
    # 模型精度设置
    parser.add_argument('--fp32_layer_names', type=str, default='',
                        help='该层设为FP32精度')
    parser.add_argument('--fp16_layer_names', type=str, default='',
                        help='该层设为FP16精度, 默认为YOLOv8s的Detect层model.22和node_of_output0, YOLOv8s-p6的Detect层对应model.30')
    args = parser.parse_args()
    
    return args

def create_dirs(path):
    """创建目录（如有需要）"""
    if not os.path.exists(path):
        os.makedirs(path, mode=0o777)

def run_pt_to_trt(args, output_dir):
    """步骤1: PT模型转INT8 TRT引擎"""
    print("===== 开始模型转换 =====")
    engine_path = os.path.join(output_dir, 'trt_engine', f'{os.path.splitext(os.path.basename(args.pt_model))[0]}-int8.engine')
    cache_path = os.path.join(output_dir, 'trt_engine', 'calibration.cache')

    # 创建引擎输出目录
    create_dirs(os.path.dirname(engine_path))

    # 构建转换命令 - 添加engine_path参数
    cmd = [
        'python', 'pt_to_trt.py',
        '--model_file', args.pt_model,
        '--engine_path', engine_path,  # 传递您定义的engine_path
        '--dtype', 'int8',
        '--width', str(args.width_int8),
        '--height', str(args.height_int8),
        '--batch_size', str(args.batch_size),
        '--calib_img_dir', args.calib_img_dir,
        '--calib_cache', cache_path,
        '--fp32_layer_names', args.fp32_layer_names,
        '--fp16_layer_names', args.fp16_layer_names,
    ]

    # 执行转换
    subprocess.run(cmd, check=True)
    if not os.path.exists(engine_path):
        raise RuntimeError("TRT引擎生成失败！")
    print(f"===== 模型转换完成: {engine_path} =====")
    return engine_path

def run_eval_int8_trt(args, engine_path, output_dir):
    """步骤2: 使用TRT引擎推理并生成结果"""
    print("===== int8开始推理 =====")
    infer_output_dir = os.path.join(output_dir, 'inference_results')
    create_dirs(infer_output_dir)
    # 构建推理命令
    cmd = [
        'python', 'eval_yolo_trt.py',
        '--model', engine_path,
        '--imgs_dir', args.test_img_dir,
        '--annotations', args.gt_label_dir,
        '--outpath', infer_output_dir,
        '--conf_thres', str(args.conf_thres),
        '--iou_thres', str(args.iou_thres),
        '--img_size_w', str(args.width_int8),
        '--img_size_h', str(args.height_int8),
        # 使用命令行传入的categories参数
        '--algo_name', args.algo_name,
        '--infer_type', 'int8',
    ]

    # 执行推理
    subprocess.run(cmd, check=True)
    print(f"===== 推理完成，结果保存至: {infer_output_dir} =====")
    return os.path.join(infer_output_dir, 'txt_results')

def run_eval_fp16_trt(args, fp16_trt_path, output_dir):
    """步骤2: 使用TRT引擎推理并生成结果"""
    print("===== fp16开始推理 =====")
    infer_output_dir = os.path.join(output_dir, 'inference_results')
    create_dirs(infer_output_dir)
    # 构建推理命令
    cmd = [
        'python', 'eval_yolo_trt.py',
        '--model', fp16_trt_path,
        '--imgs_dir', args.test_img_dir,
        '--annotations', args.gt_label_dir,
        '--outpath', infer_output_dir,
        '--conf_thres', str(args.conf_thres),
        '--iou_thres', str(args.iou_thres),
        '--img_size_w', str(args.width_fp16),
        '--img_size_h', str(args.height_fp16),
        # 使用命令行传入的categories参数
        '--algo_name', args.algo_name,
        '--infer_type', 'fp16',
    ]

    # 执行推理
    subprocess.run(cmd, check=True)
    print(f"===== 推理完成，结果保存至: {infer_output_dir} =====")
    return os.path.join(infer_output_dir, 'txt_results')

def run_cal_pr(args, pred_dir, output_dir):
    """步骤3: 计算精度和召回率"""
    eval_output_dir = os.path.join(output_dir, 'evaluation_results')
    create_dirs(eval_output_dir)

    # 构建评估命令
    cmd = [
        'python', 'cal_pr.py',
        '--annotation_dir', args.gt_label_dir,
        '--prediction_dir', pred_dir,
        '--calibration_labels_dir', args.calibration_labels_dir,
        '--conf_thres', str(args.conf_thres),
        '--iou_thres', str(args.iou_thres),
        '--classes', args.classes
    ]

    # 执行评估并保存输出日志
    with open(os.path.join(eval_output_dir, 'evaluation.log'), 'w') as f:
        subprocess.run(cmd, check=True, stdout=f, stderr=subprocess.STDOUT)
    print(f"===== 评估完成，结果保存至: {eval_output_dir} =====")


def run_cal_map(args, pred_dir, output_dir):
    """步骤4: 计算mAP50"""
    eval_output_dir = os.path.join(output_dir, 'evaluation_results')
    create_dirs(eval_output_dir)

    # 构建评估命令
    cmd = [
        'python', 'cal_map.py',
        '--annotation_dir', args.gt_label_dir,
        '--prediction_dir', pred_dir,
        '--conf_thres', str(args.conf_thres),
        '--algo_name', args.algo_name
    ]

    # 执行评估并保存输出日志
    with open(os.path.join(eval_output_dir, 'evaluation_map.log'), 'w') as f:
        subprocess.run(cmd, check=True, stdout=f, stderr=subprocess.STDOUT)
    print(f"===== 评估完成，结果保存至: {eval_output_dir} =====")
def main():
    args = parse_args()
    output_root = args.output_root

    # 清理旧结果（可选）
    if os.path.exists(output_root):
        shutil.rmtree(output_root)

    try:
        # 步骤1: PT转INT8 TRT
        engine_path = run_pt_to_trt(args, output_root)
        fp16_trt_path = args.fp16_trt_model
        # 步骤2: TRT推理
        pred_txt_int8_dir = run_eval_int8_trt(args, engine_path, os.path.join(output_root, 'int8_engine_results'))
        pred_txt_fp16_dir = run_eval_fp16_trt(args, fp16_trt_path, os.path.join(output_root, 'fp16_trt_results'))
        # 步骤3: 精度评估
        print("===== int8开始评估 =====")
        run_cal_pr(args, pred_txt_int8_dir, os.path.join(output_root, 'int8_engine_results'))
        print("===== int8开始计算map =====")
        run_cal_map(args, pred_txt_int8_dir, os.path.join(output_root, 'int8_engine_results'))
        print("===== fp16开始评估 =====")
        run_cal_pr(args, pred_txt_fp16_dir, os.path.join(output_root, 'fp16_trt_results'))
        print("===== fp16开始计算map =====")
        run_cal_map(args, pred_txt_fp16_dir, os.path.join(output_root, 'fp16_trt_results'))

        print("\n==================== 全流程执行完成 ====================")
        print(f"int8结果总览:\n- TRT引擎: {engine_path}\n- 推理结果: {os.path.dirname(pred_txt_int8_dir)}\n- 评估报告: {os.path.join(output_root, 'int8_engine_results/' + 'evaluation_results')}")
        print(f"fp16结果总览:\n- TRT引擎: {fp16_trt_path}\n- 推理结果: {os.path.dirname(pred_txt_fp16_dir)}\n- 评估报告: {os.path.join(output_root, 'fp16_trt_results/' + 'evaluation_results')}")
    except Exception as e:
        print(f"流程执行失败: {str(e)}")
        exit(1)

if __name__ == '__main__':
    main()